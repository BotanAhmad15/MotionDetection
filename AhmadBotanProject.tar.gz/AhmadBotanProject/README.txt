Steps: 
Project was coded in VSCode using opencv (python3).
1) Unzip Project
2) Install pygame for music (mp3.mp3 file is background song for the 'game'):
- In cmd type pip install pygame
3) Ensure a webcam is plugged in 
4) run code using vscode 'Run without debugging'

Source code: Included in Project.py

Dataset: Img of moved body part will be saved creating our own dataset 
filled with losses called Failed1, Failed2, etc. These will be store in the Database
folder

Example input/output data: Project is simulated through a webcam input data 
will be through a image through webcam.
Output webcam window should appear similar to Failure1.png included in Database folder. 



